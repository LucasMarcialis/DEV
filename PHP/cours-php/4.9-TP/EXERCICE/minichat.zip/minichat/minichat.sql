-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 29 août 2018 à 15:50
-- Version du serveur :  5.7.21
-- Version de PHP :  5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `test`
--

-- --------------------------------------------------------

--
-- Structure de la table `minichat`
--

DROP TABLE IF EXISTS `minichat`;
CREATE TABLE IF NOT EXISTS `minichat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date_message` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `minichat`
--

INSERT INTO `minichat` (`id`, `pseudo`, `message`, `date_message`) VALUES
(112, 'Lucas', 'L\'arroseur arrosé', '2018-08-29 17:37:02'),
(111, 'Pierre', 'Très drôle ..', '2018-08-29 17:36:49'),
(110, 'Lucas', 'Ciseaux', '2018-08-29 17:36:41'),
(109, 'Paul', 'Feuille', '2018-08-29 17:36:20'),
(108, 'Pierre', 'Oui ?', '2018-08-29 17:36:13'),
(107, 'Paul', 'Pierre', '2018-08-29 17:36:08'),
(106, 'Pierre', 'Je m\'ennuie ...', '2018-08-29 17:35:54'),
(105, 'Paul', 'Ouais ben va trouver l\'inspiration', '2018-08-29 17:35:46'),
(104, 'Lucas', 'Pensez au faut qu\'on a besoin de tester que la pagination s\'affiche bien les gars !', '2018-08-29 17:35:37'),
(103, 'Paul', 'En vrai je sais plus trop quoi dire pour rajouter des entrées dans la base', '2018-08-29 17:35:10'),
(102, 'Pierre', 'Bon maintenant il va falloir combler', '2018-08-29 17:34:54'),
(101, 'Lucas', 'J\'avoue qu\'un petit melon ne serait pas de refus !', '2018-08-28 14:55:34'),
(100, 'Pierre', 'Ça me donne faim tout ça ..', '2018-08-28 14:55:12'),
(99, 'Lucas', 'J\'en peux plus de lui ...', '2018-08-28 14:47:30'),
(98, 'Paul', 'Double lourdeur ..', '2018-08-28 14:47:22'),
(97, 'Pierre', 'Melon ?', '2018-08-28 14:47:13'),
(96, 'Lucas', 'Chapeau !', '2018-08-28 14:47:06'),
(95, 'Paul', 'Merci, je l\'ai développé entièrement en PHP :)', '2018-08-28 14:46:59'),
(94, 'Lucas', 'En parlant de lourd, très sympa ton nouveau site Paul !', '2018-08-28 14:46:48'),
(93, 'Paul', 'Lourdeur quand tu nous tiens ..', '2018-08-28 14:46:29'),
(92, 'Lucas', 'Sacré Pierre, toujours le mot pour rire !', '2018-08-28 14:45:59'),
(91, 'Pierre', 'Oui m\'enfin là, tu commences bien bas :\')', '2018-08-28 14:45:42'),
(90, 'Lucas', 'Il faut bien commencer petit pour aller haut ;)', '2018-08-28 14:45:22'),
(89, 'Paul', 'On a vu des discours plus éloquent !', '2018-08-28 14:45:08'),
(88, 'Pierre', 'Quel premier message :O ', '2018-08-28 14:42:28'),
(87, 'Lucas', 'Voici le premier message de ce chat !', '2018-08-28 14:40:46');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
